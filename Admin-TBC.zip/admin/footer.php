<?php
echo '<div class="f1"><a href="'.$ss->settings['url'].'">'.escape($ss->settings['title']).'</a></div>
<div class="db">By  :- <a href="https://www.facebook.com/techiey" ><b>Techiey.com</b></a><br\>For More Scripts, Goto <a href="https://techiey.com">Techiey.com</a></div>
</body>
</html>';