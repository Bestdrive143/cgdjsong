<?php

include_once('./assets/ads/footer.php');

echo '<h2>
	<b>
		 <a href="'.$ss->settings['url'].'"> <font color="#ffffff"> &copy 2016-17 '.$ss->settings['title'].'</font> </a>
     <br/><a href="/assets/disclaimer.php"><font color="#ffffff">Disclaimer</font></a> | <a href="/contact"><font color="#ffffff">Contact Us</font></a></b></h2>
  </h2>

<div align="Center">Powered by :- <a href="http://djnice.in"  target="_blank"><b>Dj YuYu</b></a></div>


</body>
</html>';